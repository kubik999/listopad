var x = document.getElementsByTagName("li");

 x[0].addEventListener("click", function(){
x[0].style.transform= "scale(1.2)";
x[1].style.transform= "scale(1.0)";
x[2].style.transform= "scale(1.0)";
x[3].style.transform= "scale(1.0)";
x[4].style.transform= "scale(1.0)";
x[5].style.transform= "scale(1.0)";
x[6].style.transform= "scale(1.0)";
x[7].style.transform= "scale(1.0)";
document.getElementById("lista").style.left="316px";

//var divSrodek=document.getElementById("srodek");
//var newEl = document.createElement('img');
//newEl.src = "img/aa.jpg";
//divSrodek.appendChild(newEl);   
 }, false);

 x[1].addEventListener("click", function(){
x[0].style.transform= "scale(1.0)";
x[1].style.transform= "scale(1.2)";
x[2].style.transform= "scale(1.0)";
x[3].style.transform= "scale(1.0)";
x[4].style.transform= "scale(1.0)";
x[5].style.transform= "scale(1.0)";
x[6].style.transform= "scale(1.0)";
x[7].style.transform= "scale(1.0)";
document.getElementById("lista").style.left="196px";
 }, false);
 
  x[2].addEventListener("click", function(){
x[1].style.transform= "scale(1.0)";
x[2].style.transform= "scale(1.2)";
x[3].style.transform= "scale(1.0)";
x[4].style.transform= "scale(1.0)";
x[5].style.transform= "scale(1.0)";
x[6].style.transform= "scale(1.0)";
x[7].style.transform= "scale(1.0)";
document.getElementById("lista").style.left="76px";
 }, false);
 
  x[3].addEventListener("click", function(){
x[1].style.transform= "scale(1.0)";
x[2].style.transform= "scale(1.0)";
x[3].style.transform= "scale(1.2)";
x[4].style.transform= "scale(1.0)";
x[5].style.transform= "scale(1.0)";
x[6].style.transform= "scale(1.0)";
x[7].style.transform= "scale(1.0)";
document.getElementById("lista").style.left="-44px";
 }, false);
 
  x[4].addEventListener("click", function(){
x[1].style.transform= "scale(1.0)";
x[2].style.transform= "scale(1.0)";
x[3].style.transform= "scale(1.0)";
x[4].style.transform= "scale(1.2)";
x[5].style.transform= "scale(1.0)";
x[6].style.transform= "scale(1.0)";
x[7].style.transform= "scale(1.0)";
document.getElementById("lista").style.left="-164px";
 }, false);
 
   x[5].addEventListener("click", function(){
x[1].style.transform= "scale(1.0)";
x[2].style.transform= "scale(1.0)";
x[3].style.transform= "scale(1.0)";
x[4].style.transform= "scale(1.0)";
x[5].style.transform= "scale(1.2)";
x[6].style.transform= "scale(1.0)";
x[7].style.transform= "scale(1.0)";
document.getElementById("lista").style.left="-284px";
 }, false);
 
   x[6].addEventListener("click", function(){
x[1].style.transform= "scale(1.0)";
x[2].style.transform= "scale(1.0)";
x[3].style.transform= "scale(1.0)";
x[4].style.transform= "scale(1.0)";
x[5].style.transform= "scale(1.0)";
x[6].style.transform= "scale(1.2)";
x[7].style.transform= "scale(1.0)";
document.getElementById("lista").style.left="-404px";
 }, false);
 
    x[7].addEventListener("click", function(){
x[1].style.transform= "scale(1.0)";
x[2].style.transform= "scale(1.0)";
x[3].style.transform= "scale(1.0)";
x[4].style.transform= "scale(1.0)";
x[5].style.transform= "scale(1.0)";
x[6].style.transform= "scale(1.0)";
x[7].style.transform= "scale(1.2)";
document.getElementById("lista").style.left="-524px";
 }, false);
 
